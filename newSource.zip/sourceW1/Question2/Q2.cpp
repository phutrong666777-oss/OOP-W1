#include "Q2.h"

    Point Point::getPoint(){
            Point c;
            cout<<"Enter Your Point:"<<"\n";

            cout<<"Enter x Point:";
            cin>>c.x;

            cout<<"Enter y Point:";
            cin>>c.y;

            return c;
        }

    void Point::printPoint(){
        cout<<"Your Point Is:"<<"("<<x<<","<<y<<")"<<"\n";
    }

    void Point::calcDistance(){
        cout<<"Caculate The Distance Of Two Point:"<<"\n";
        Point a=getPoint();
        Point b=getPoint();
        
        int x=calcNewCoordinates(a.x,b.x);
        int y=calcNewCoordinates(a.y,b.y);

        float distance=sqrt(pow(x,2)+pow(y,2));
        cout<<"The Distance is:"<<distance;
    }

    float Point::calcNewCoordinates(float x, float y){
        return abs(x-y);
    }

int main(){
    Point a;

    a=a.getPoint();
    a.printPoint();
    a.calcDistance();

}