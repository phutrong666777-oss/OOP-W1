#include<iostream>
#include<cmath>
using namespace std;
class Point{
    float x;
    float y;

public:
    Point getPoint();

    void printPoint();

    void calcDistance();

private:
    float calcNewCoordinates(float x, float y);

};