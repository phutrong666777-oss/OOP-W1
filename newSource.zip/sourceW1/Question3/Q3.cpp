#include "Q3.h"

Rectangle Rectangle::getRectangle(){
        cout<<"Enter 4 Vertes For Your Rectangle:"<<"\n";
        Rectangle a;

        a.VertexA=getVertex(VertexA);
        a.VertexB=getVertex(VertexB);
        a.VertexC=getVertex(VertexC);
        a.VertexD=getVertex(VertexD);

        return a;
    }

    void Rectangle::printRectangle(Rectangle a){
        cout<<"Vertes A ";
        a.VertexA.printPoint(a.VertexA);

        cout<<"Vertes B ";
        a.VertexB.printPoint(a.VertexB);

        cout<<"Vertes C ";
        a.VertexC.printPoint(a.VertexC);

        cout<<"Vertes D ";
        a.VertexD.printPoint(a.VertexD);
    }

    bool Rectangle::isValidRectangle(Rectangle a){
        
        int angleB=dotProduct(a.VertexA,a.VertexB,a.VertexC);
        int angleC=dotProduct(a.VertexB,a.VertexC,a.VertexD);
        int angleD=dotProduct(a.VertexA,a.VertexD,a.VertexC);

        return angleB==0&&angleC==0&&angleD==0;
    }

    void Rectangle::printPerimeter(Rectangle a){
        Point p;

        float AB=p.calcDistance(a.VertexA,a.VertexB);
        float BC=p.calcDistance(a.VertexB,a.VertexC);
        float CD=p.calcDistance(a.VertexC,a.VertexD);
        float DA=p.calcDistance(a.VertexD,a.VertexA);

        int P=AB+BC+CD+DA;
        cout<<"Perimeter Of Your Rectangle Is:"<<P<<"\n";
    }

    void Rectangle::printSquare(Rectangle a){
        Point p;

        float AB=p.calcDistance(a.VertexA,a.VertexB);
        float BC=p.calcDistance(a.VertexB,a.VertexC);

        int S=AB*BC;
        cout<<"Square Of Your Rectangle Is:"<<S<<"\n";
    } 

    Point Rectangle::getVertex(Point v){
        cout<<"Enter Your Vertes:"<<"\n";
        v=v.getPoint();

        return v;
    }

    int Rectangle::dotProduct(Point A, Point B, Point C){
        int BAx=A.x-B.x;
        int BAy=A.y-B.y;
        int BCx=C.x-B.x;
        int BCy=C.y-B.y;

        return BAx*BCx+BAy*BCy;
    }

int main(){
    Rectangle a;
    a=a.getRectangle();
    a.printRectangle(a);
    if(a.isValidRectangle(a)){
        cout<<"Is Valid Rectangle"<<"\n";
        a.printPerimeter(a);
        a.printSquare(a);
    }else{
        cout<<"Is InValid Rectangle";
    }
    
}