#include "point.h"

using namespace std;
class Rectangle{
    Point VertexA;
    Point VertexB;
    Point VertexC;
    Point VertexD;

public:
    Rectangle getRectangle();

    void printRectangle(Rectangle a);

    bool isValidRectangle(Rectangle a);

    void printPerimeter(Rectangle a);

    void printSquare(Rectangle a);

private:
    Point getVertex(Point v);

    int dotProduct(Point A, Point B, Point C);

};