#include<iostream>
#include<cmath>
using namespace std;
class Point{

public:
    float x;
    float y;
    Point getPoint(){
        Point c;
        cout<<"Enter Your Point:"<<"\n";

        cout<<"Enter x Point:";
        cin>>c.x;

        cout<<"Enter y Point:";
        cin>>c.y;

        return c;
    }

    void printPoint(Point c){
        cout<<"Your Point Is:"<<"("<<c.x<<","<<c.y<<")"<<"\n";
    }

    float calcDistance(Point a, Point b){
        
        int x=calcNewCoordinates(a.x,b.x);
        int y=calcNewCoordinates(a.y,b.y);

        float distance=sqrt(pow(x,2)+pow(y,2));

        return distance;
    }

private:
    float calcNewCoordinates(float x, float y){
        return abs(x-y);
    }

};