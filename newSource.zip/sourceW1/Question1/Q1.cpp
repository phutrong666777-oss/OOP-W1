#include "Q1.h"

    Fraction Fraction::getFraction(){
            Fraction c;

            cout<<"Enter your fracion:"<<"\n";

            cout<<"Enter your numerator:";
            cin>>c.num;

            cout<<"Enter your denominator:";
            cin>>c.den;

            while(c.den==0){
                cout<<"Your Denominator Is Invalid"<<"\n";
                cout<<"Please Re-Enter Your Denominator:";
                cin>>c.den;
            }

            return c;
        }

    void Fraction::printFraction(Fraction c){
        float res=(float) c.num/c.den;

        cout<<"Decimal form:"<<res<<"\n";
        cout<<"Fraction form:"<<c.num<<"/"<<c.den<<"\n";

    }
    
    void Fraction::calcSumFraction(){
        cout<<"Calculate The Sum Of Two Fraction:"<<"\n";
        Fraction a=getFraction();
        Fraction b=getFraction();

        Fraction res;
        int num=a.num*b.den+b.num*a.den;
        int den=a.den*b.den;
        res=simplifyFraction(num,den);

        printFraction(res);

    }

    void Fraction::calcDifferenceFraction(){
        cout<<"Calculate The Difference Of Two Fraction:"<<"\n";
        Fraction a=getFraction();
        Fraction b=getFraction();

        Fraction res;
        int num=a.num*b.den-b.num*a.den;
        int den=a.den*b.den;
        res=simplifyFraction(num,den);

        printFraction(res);

    }

    void Fraction::calcMultiplyFraction(){
        cout<<"Calculate The Product Of Two Fractions:"<<"\n";
        Fraction a=getFraction();
        Fraction b=getFraction();

        Fraction res;
        int num=a.num*b.num;
        int den=a.den*b.den;
        res=simplifyFraction(num,den);

        printFraction(res);
    }

    void Fraction::calcQuotientFraction(){
        cout<<"Calculate The Quotient Of Two Fractions"<<"\n";
        Fraction a=getFraction();
        Fraction b=getFraction();

        Fraction res;
        int num=a.num*b.den;
        int den=a.den*b.num;
        res=simplifyFraction(num,den);

        printFraction(res);
    }

    Fraction Fraction::simplifyFraction(int a, int b){
        int GCD=gcd(a,b);
        Fraction res;

        res.num=a/GCD;
        res.den=b/GCD;

        return res;
    }
int main(){

    Fraction a;
    a.printFraction(a.getFraction());
    a.calcSumFraction();
    a.calcDifferenceFraction();
    a.calcMultiplyFraction();
    a.calcQuotientFraction();

}