#include<iostream>
#include<numeric>
using namespace std;
class Fraction{
    int num;
    int den;

public:

    Fraction getFraction();

    void printFraction(Fraction c);
    
    void calcSumFraction();

    void calcDifferenceFraction();

    void calcMultiplyFraction();

    void calcQuotientFraction();

private:

    Fraction simplifyFraction(int a, int b);

};
